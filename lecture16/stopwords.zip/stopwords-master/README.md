# 中文常用停用词表

| 词表名 | 词表文件 |
| - | - |
| 中文停用词表                   | cn\_stopwords.txt    |
| 哈工大停用词表                 | hit\_stopwords.txt   |
| 百度停用词表                   | baidu\_stopwords.txt |
| 四川大学机器智能实验室停用词库 | scu\_stopwords.txt   |


请吃辣条

![](https://raw.githubusercontent.com/goto456/markdown-pictures/master/wengeblog/re2.jpg)

### GitHub仓库星标统计
<!--替换成自己的仓库和名字就可以用了-->
[![Stargazers over time](https://starchart.cc/goto456/stopwords.svg)](https://starchart.cc/goto456/stopwords)

